var username;

var password;

var age;

username="sai";

console.log(username);

console.log(password);

console.log(age);