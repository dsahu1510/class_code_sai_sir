var arr= [ {
      id:101,
      name:"ravi"
},
{
    id:101,
    name:"ravi"
},
{
    id:101,
    name:"ravi"
},
{
    id:101,
    name:"ravi"
},
{
    id:101,
    name:"ravi"
}];

console.log(arr[0].)