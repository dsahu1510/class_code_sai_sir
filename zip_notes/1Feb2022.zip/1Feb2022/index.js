// var str="&";
// var  pattern= /./;
// console.log(pattern.test(str));


var str="A1H";

var pattern=/^[A-Z]{1,3}[0-9]+H$/;
console.log(pattern.test(str));