
var date = new Date();

  console.log(date.getDate(), date.getDay(), date.getMonth(), date.getFullYear());
