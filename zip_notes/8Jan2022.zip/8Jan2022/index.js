
// for ( var i =0; ; i++){
//     console.log(i);
// }


while(){
    console.log("hello");
}