 

  var x =[1,2,3,4,5,7];

  for(var i=0;i<x.length;i++){
      if(x[i] == 3){
          continue;
      }
      console.log(x[i]);
  }