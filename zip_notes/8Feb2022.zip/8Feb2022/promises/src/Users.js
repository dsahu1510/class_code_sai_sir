import React from 'react';
import axios from 'axios';
class Users extends React.Component{

     componentDidMount(){
         console.log("componentDidMount called");

         axios.get("https://jsonplaceholder.typicode.com/users").then(
             response => {
                 console.log(response.data);
             },
             error => {
                 console.log(error);
             }
         )

     }

    render(){
        return(
            <div>
                <h1>Users</h1>
            </div>
        )
    }
}
export default Users;