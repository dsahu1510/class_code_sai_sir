var obj = {x:10};
console.log(obj);

obj = null;

console.log(obj);