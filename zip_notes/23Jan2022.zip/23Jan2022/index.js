var str = "hello ";
str= str.concat("world ");
console.log(str);
console.log(str.toUpperCase());
console.log(str.endsWith(" "));
console.log(str.startsWith("hello"));
var strs =str.split(" ");
console.log(strs);
var url="http://www.facebook.com";
var username="Sai";
console.log(username.link(url));
console.log(username.bold());



