

  function isAdmin(username){
     if(username == "sai"){
         console.log(username+ " is an admin");
     }
     else
     {
        console.log(username+ " is not an admin");
     }
  }

    isAdmin("sai");
