function Employee(eid,ename){
      this.eid=eid;
      this.ename=ename;
      this.login = () => {};
      this.logout = () => {};
}


var emp = new Employee();
console.log(emp);

var emp1 = new Employee();
console.log(emp1);