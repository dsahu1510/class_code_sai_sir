import React from 'react';

 class Login extends React.Component{

    render(){
        return(
            <div>
                <h1>I am Login Component!</h1>
            </div>
        )
    }

}
export default Login;
