import React from 'react';
import Login from './Login';

class App extends React.Component{

  render(){
    return(
      <div>
        <h1>Hello I am App Component</h1>
        <Login></Login>
      </div>
    )
  }

}

export default App;